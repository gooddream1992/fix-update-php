<?php
/*
Plugin Name: Dealn.It DealFeed by Category
Plugin URI: http://www.dealn.it/
Description: A Widget that Outputs deals from dealn.it database based on specified category(ies). Go to widget menu after activating to configure options. Requires PHP 5+
Author: Dealn.It
Version: 0.5
Author URI: http://www.dealn.it/
*/
/**
 * @package DealFeedByCategory
 * @version 0.5
 */

class DealFeedByCategoryWidget extends WP_Widget {
	private $_basicuser;
	private $_basicpass;
	private $_limit_min;
	private $_limit_max;
	private $_pub_id;
	
	function __construct() {
		// needed for basic authentication
		$this->_basicuser = 'bloguser';
		$this->_basicpass = 'blogBLOG2112';
		// change limits, if wanted
		$this->_limit_min = 1;
		$this->_limit_max = 15;
		$this->_pub_id = 1;
		
		$widget_options = array('description' => 'A widget to list deals based on selected categories.');
		parent::__construct(false, 'Dealn.It Deal Feed by Category', $widget_options);	
	}

	/** 
	 * @see WP_Widget::widget 
	 */
	function widget($args, $instance) {	
		$before_widget = '';
		$after_widget = '';
		$before_title = '';
		$after_title = '';
		extract( $args );
		
		if (!array_key_exists('categories', $instance)) 
			$instance['categories'] = array();
		if (!array_key_exists('limit', $instance)) 
			$instance['limit'] = $this->_limit_min;
		if (!array_key_exists('pub_id', $instance)) 
			$instance['pub_id'] = $this->_pub_id;
			
		// test, bad category
//		$data['categories'] = array('checken feed');
		
		// setup categories to add to the remote_get url
		$arrCategories = array();
		foreach ($instance['categories'] as $strCategory) {
			$arrCategories[] = sprintf("category[]=%s", urlencode($strCategory));
			$strTitle = htmlspecialchars($strCategory);
		}
		
		// only allow between n and m results
		$dLimit = (int)$instance['limit'];
		if ($dLimit > $this->_limit_max)
			$dLimit = $this->_limit_max;
		if ($dLimit < $this->_limit_min)
			$dLimit = $this->_limit_min;
		
		// setup basic authentication for wp_remote_get, if needed
		$remote_args = array(
			'headers' => array(
				'Authorization' => 'Basic '.base64_encode($this->_basicuser.':'.$this->_basicpass)
				)
			);
		// 'all' categories selected?
		if (array_search('All', $instance['categories']) !== FALSE) {
			$url = 'http://dealn.it/api-deals-by_location.htm?limit='.$dLimit;
		} else {
			$url = 'http://dealn.it/api-deals-by_category.htm?limit='.$dLimit.'&'.implode('&', $arrCategories);
		}
		// use geo_ip to show closest deals first
		$url .= '&remote_addr='.$_SERVER['REMOTE_ADDR'];
		// who are we...
		$url .= '&http_host='.$_SERVER['HTTP_HOST'];
		$remote_result = wp_remote_get($url,$remote_args);
		if (is_wp_error($remote_result)) {
			echo '<span style="color:red;">Critical: Error retrieving deals from remote server.</span>';
			return false;
		}
		$deals = json_decode($remote_result['body']);
		
		// setup what we're going to output
		$strTestOutput = '';
		foreach ($deals as $objDeal) {
			// if click url, it is probably a deal
			if (strlen($objDeal->ClickUrl)) {
				$strClickUrl = sprintf("%s%spid=%d"
					, $objDeal->ClickUrl
					, strpos($objDeal->ClickUrl, '?')?'&':'?'
					, $instance['pub_id']
					);
				$strImage = '';
				if (strlen($instance['show_image']) && strlen($objDeal->PhotoMedium)) {
					$strImage = sprintf("<img src='%s' align='left' %s=%d style='margin:4px;' border=0 alt=\"%s\">\n"
						, $objDeal->PhotoMedium
						, $instance['image_limit']
						, $instance['image_px']
						, htmlentities($objDeal->Title)
						);
				}
				$strTestOutput .= sprintf("<li><a href=%s title=\"%s: %s\">%s%s</a></li><br>\n"
					, $strClickUrl
					, $objDeal->DivisionName
					, strlen($objDeal->Subject)?$objDeal->Subject:$objDeal->Title
					, $strImage
					, $objDeal->Title
					);
			}
		}
		if (!strlen($strTestOutput)) {
			$strTestOutput = '<li> - None found - </li>';
			$strTitle = 'Local Deals';
		}
		if (array_key_exists('title', $instance) && strlen(trim($instance['title']))) {
			$strTitle = $instance['title'];
		}
		
		$strTitle = apply_filters('widget_title', $strTitle);
		?>
			<?php echo $before_widget; ?>
			<?php if ( $strTitle )
				echo $before_title . $strTitle . $after_title; ?>
			<ul><?php echo $strTestOutput; ?></ul>
			<?php echo $after_widget; ?>
		<?php
	}

	/** 
	 * @see WP_Widget::update 
	 */
	function update($new_instance, $old_instance) {	
		
		if (array_key_exists('dfbc_action', $new_instance)) {
			// reset categories in options array, then add new
			$old_instance['categories'] = array();
			if (array_key_exists('dfbc_options', $new_instance) && is_array($new_instance['dfbc_options'])) {
				foreach ($new_instance['dfbc_options'] as $strCategory) {
					$old_instance['categories'][] = $strCategory;
				}
			}
			if (array_key_exists('dfbc_limit', $new_instance)) {
				$old_instance['limit'] = (int)$new_instance['dfbc_limit'];
				if ($old_instance['limit'] > $this->_limit_max)
					$old_instance['limit'] = $this->_limit_max;
				if ($old_instance['limit'] < $this->_limit_min)
					$old_instance['limit'] = $this->_limit_min;
			}
			if (array_key_exists('dfbc_pub_id', $new_instance)) {
				$old_instance['pub_id'] = (int)$new_instance['dfbc_pub_id'];
			}
			if (array_key_exists('dfbc_title', $new_instance)) {
				$old_instance['title'] = $new_instance['dfbc_title'];
			}
			// reset checkbox
			unset($old_instance['show_image']);
			if (array_key_exists('dfbc_show_image', $new_instance)) {
				$old_instance['show_image'] = $new_instance['dfbc_show_image'];
			}
			if (array_key_exists('dfbc_image_limit', $new_instance)) {
				$old_instance['image_limit'] = $new_instance['dfbc_image_limit'];
			}
			if (array_key_exists('dfbc_image_px', $new_instance)) {
				$old_instance['image_px'] = $new_instance['dfbc_image_px'];
			}
		}
		return $old_instance;
	}

	/** 
	 * @see WP_Widget::form 
	 */
	function form($instance) {	
		if (!array_key_exists('categories', $instance)) 
			$instance['categories'] = array();
		if (!array_key_exists('limit', $instance)) 
			$instance['limit'] = $this->_limit_min;
		
		echo "<p>Current Categories:</p>\n";
		foreach ($instance['categories'] as $strCategory) {
			echo " &nbsp;".htmlspecialchars($strCategory)."<br>\n";
		}
		if (!is_array($instance['categories']) || !count($instance['categories'])) {
			echo ' &nbsp; - None -<br>';
			$instance['categories'] = array();
		}
		
		// setup basic authentication for wp_remote_get, if needed
		$remote_args = array(
			'headers' => array(
				'Authorization' => 'Basic '.base64_encode($this->_basicuser.':'.$this->_basicpass)
				)
			);
		$remote_result = wp_remote_get('http://dealn.it/api-deals-by_category.htm?limit=100',$remote_args);
		if (is_wp_error($remote_result)) {
			echo '<span style="color:red;">Critical: Error retrieving category list from remote server.</span>';
			return false;
		}
		$categories = json_decode($remote_result['body']);
		
		// add all option
		$objAll = new stdClass();
		$objAll->score = 100;
		$objAll->taxonomy_name = 'All';
		$categories = array_merge(array($objAll),$categories);
		
		echo "<br><p>Change Categories: (score)</p>\n";
		// since we're using checkboxes, we need a control input in case all checkboxes are unchecked
		printf("<input type=hidden id=\"%s\" name=\"%s\" value=true>\n"
			, $this->get_field_id('dfbc_action')
			, $this->get_field_name('dfbc_action')
			);
		foreach ($categories as $objCategory) {
			printf("<input %s type=checkbox id=\"%s\" name=\"%s[]\" value='%s'>%s (%d)<br>\n"
				// check the box if category is in options array
				, array_search($objCategory->taxonomy_name, $instance['categories']) !== FALSE?'checked':''
				, $this->get_field_id('dfbc_options')
				, $this->get_field_name('dfbc_options')
				, htmlspecialchars($objCategory->taxonomy_name)
				, htmlspecialchars($objCategory->taxonomy_name)
				, $objCategory->score
				);
		}
		echo "<br><p>Number of deals to show:</p>\n";
		printf("<input type=text size=4 id=\"%s\" name=\"%s\" value=%d>\n"
			, $this->get_field_id('dfbc_limit')
			, $this->get_field_name('dfbc_limit')
			, $instance['limit']
			);
		echo "<br><br><p>Title to display:</p>\n";
		printf("<input type=text size=25 id=\"%s\" name=\"%s\" value=\"%s\">\n"
			, $this->get_field_id('dfbc_title')
			, $this->get_field_name('dfbc_title')
			, htmlspecialchars($instance['title'])
			);
		echo "<br><br><p>Show Image:</p>\n";
			printf("<input %s type=checkbox id=\"%s\" name=\"%s\" value='1'>\n"
				, array_key_exists('show_image', $instance) !== FALSE?'checked':''
				, $this->get_field_id('dfbc_show_image')
				, $this->get_field_name('dfbc_show_image')
				);
			printf("<select id=\"%s\" name=\"%s\">\n"
				, $this->get_field_id('dfbc_image_limit')
				, $this->get_field_name('dfbc_image_limit')
				);
			printf("<option %s value=\"width\">Limit Width</option>\n"
				, $instance['image_limit'] == 'width'?'selected':''
				);
			printf("<option %s value=\"height\">Limit Height</option>\n"
				, $instance['image_limit'] == 'height'?'selected':''
				);
			printf("</select>");
			printf("<input type=text size=2 id=\"%s\" name=\"%s\" value=%d>px\n"
				, $this->get_field_id('dfbc_image_px')
				, $this->get_field_name('dfbc_image_px')
				, $instance['image_px']
				);
		echo "<br><br><p>Your Dealn.It Publisher ID:</p>\n";
		printf("<input type=text size=4 id=\"%s\" name=\"%s\" value=%d>\n"
			, $this->get_field_id('dfbc_pub_id')
			, $this->get_field_name('dfbc_pub_id')
			, $instance['pub_id']
			);
	}

} // class DealFeedByCategoryWidget

// register DealFeedByCategoryWidget widget
add_action('widgets_init', create_function('', 'return register_widget("DealFeedByCategoryWidget");'));

